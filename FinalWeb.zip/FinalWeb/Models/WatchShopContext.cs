﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace FinalWeb.Models;

public partial class WatchShopContext : DbContext
{
    public WatchShopContext()
    {
    }

    public WatchShopContext(DbContextOptions<WatchShopContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Province> Provinces { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server = localhost; Database= watchShop;User id = Huan;password=123; Encrypt=False;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Province>(entity =>
        {
            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("ID");
            entity.Property(e => e.Area).HasMaxLength(255);
            entity.Property(e => e.HeadCity).HasMaxLength(255);
            entity.Property(e => e.Population).HasMaxLength(255);
            entity.Property(e => e.Province1)
                .HasMaxLength(255)
                .HasColumnName("Province");
            entity.Property(e => e.Section).HasMaxLength(255);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Fullname).HasMaxLength(50);
            entity.Property(e => e.LastLogin).HasColumnType("datetime");
            entity.Property(e => e.Password).HasMaxLength(50);
            entity.Property(e => e.Username).HasMaxLength(50);
            entity.Property(e => e.ZipCode).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
