﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
function signOut() {
    if (confirm("Ban co muon thoat k ?") == true) {
        $.ajax({
            type: "POST",
            url: "/Login/signOut",
            async: false,
            success: function (res) {
                if (res.success) {
                    document.location.href = "/";
                } else {
                    alert(res.message);
                }
            },
            failure: function (res) {

            },
            error: function (res) {

            }
        });
    }
}

function changePass() {

    /*username = $("#txtUsername").val();*/
    username = $("#txtUsername");
    oldPass = $("#txtOldPass").val();
    pass1 = $("#txtPass1").val();
    pass2 = $("#txtPass2").val();
    if (oldPass == "" || oldPass == undefined || oldPass == null || oldPass.length < 3 ){
        alert("vui long nhap mat khau cu!");
        return;
    }
    if (pass1 == "" || pass1 == undefined || pass1 == null || pass1.length < 3 ){
        alert("vui long nhap mat khau moi!");
        return;
    }
    if (pass2 == "" || pass2 == undefined || pass2 == null || pass2.length < 3) {
        alert("vui long nhap mat khau moi!");
        return;
    }
    if (pass1 != pass2) {
        alert("mat khau moi khong trung!");
        return;
    }

    if (confirm("ban co chac muon doi pass khong? ") == true) {
        $.ajax({
            type: "POST",
            url: "/Login/change_pass",
            data: {'username': username,'oldPass':oldPass,'newPass':pass1 },
            async: false,
            success: function (res) {
                if (res.success) {
                    document.location.href = "/";
                } else {
                    alert(res.message);
                }
            },
            failure: function (res) {

            },
            error: function (res) {

            }
        });
    }
}