﻿using Microsoft.AspNetCore.Mvc;

namespace FinalWeb.Controllers
{
    public class Home1Controller : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
