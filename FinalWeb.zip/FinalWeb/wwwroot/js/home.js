﻿//var totalPage = 1;
//var lst = null;
//function selectClass(ctl) {
//    let lop = $(ctl).val();
//    if (lop != "0" && lop != undefined && lop != null) {
//        getCourse(lop, 1);
//        $("#tblResult").show(500);
//    }
//    else {
//        $("#tblResult").hide(500);
//    }
//}

//function getCourse(grp, p) {
//    $.ajax({
//        type: "POST",
//        url: "/Home/get_course",
//        data: { 'Group': grp, 'Page': p, 'Size': 5 },
//        async: false,
//        success: function (res) {
//            if (res.success) {
//                let data = res.data;
//                if (data.data != null && data.data != undefined) {
//                    let stt = (p - 1) * 5 + 1;
//                    let data1 = [];
//                    for (var i = 0; i < data.data.length; i++) {
//                        let item = data.data[i];
//                        item.STT = stt;
//                        data1.push(item);
//                        stt++;
//                    }
//                    lst = data1;
//                    $("#tblResult tbody").html("");
//                    $('#courseTemplate').tmpl(data1).appendTo("#tblResult tbody");
//                }
//                totalPage = data.totalPage;
//                $("#curPage").text(p);
//            } else {
//                alert(res.message);
//            }
//        },
//        failure: function (res) { },
//        error: function (res) { }
//    });
//}

//function goPrev() {
//    var curPage = parseInt($("#curPage").text());
//    if (curPage == 1) {
//        alert("dang o trang dau tien!!!");
//    } else {
//        var b = curPage - 1;
//        var grp = $("#selClass").val();
//        getCourse(grp, b);
//    }
//}

//function goNext() {
//    var curPage = parseInt($("#curPage").text());
//    if (curPage == totalPage) {
//        alert("dang o trang cuoi cung!!!");
//    } else {
//        var b = curPage + 1;
//        var grp = $("#selClass").val();
//        getCourse(grp, b
//        );
//    }
//}

//function openModal(id) {
//    $("#btnSave").show();
//    $("#txtInsert").hide();
//    if (lst != null && id != null && id > 0) {
//        var item = $.grep(lst, function (obj) {
//            return obj.id == id;
//        })[0];

//        $("#txtId").val(item.id);
//        $("#txtName").val(item.courseName);
//        $("#txtGroup").val(item.group);
//        $("#txtCredit").val(item.credit);
//        $("#txtCode").val(item.subCode);
//        $("#txtMajor").val(item.major);
//        $("#txtNode").val(item.note);
//    }
//}

//function save() {
//    var item = {
//        id: $("#txtId").val(),
//        courseName: $("#txtName").val(),
//        group: $("#txtGroup").val(),
//        credit: $("#txtCredit").val(),
//        subCode: $("#txtCode").val(),
//        major: $("#txtMajor").val(),
//        note: $("#txtNode").val(),
//    };
//    $.ajax({
//        type: "POST",
//        url: "/Home/update_course",
//        data: { 'course': item },
//        async: false,
//        success: function (res) {
//            if (res.success) {
//                alert("update thanh cong");
//                let c = res.data;
//                var i = 0;
//                for (i = 0; i < lst.length; i++) {
//                    if (lst[i].id == c.id) {
//                        c.STT = lst[i].STT;
//                        break;
//                    }
//                }


//                lst[i] = c;
//                console.log(lst);
//                $("#tblResult tbody").html("");
//                $("#courseTemplate").tmpl(lst).appendTo("#tblResult tbody");
//            } else {
//                alert(res.message);
//            }
//        },
//        failure: function (res) { },
//        error: function (res) { },
//    });
//}

//function addNew() {
//    $("#btnSave").hide();
//    $("#txtInsert").show();
//    $("#txtId").val("");
//    $("#txtName").val("");
//    $("#txtGroup").val("");
//    $("#txtCredit").val("");
//    $("#txtCode").val("");
//    $("#txtMajor").val("");
//    $("#txtNode").val("");
//}

//function insert() {
//    var item = {
//        id: 0,
//        courseName: $("#txtName").val(),
//        group: $("#txtGroup").val(),
//        credit: $("#txtCredit").val(),
//        subCode: $("#txtCode").val(),
//        major: $("#txtMajor").val(),
//        note: $("#txtNode").val(),
//    };


//    $.ajax({
//        type: "POST",
//        url: "/Home/insert_course",
//        data: { 'course': item },
//        async: false,
//        success: function (res) {
//            if (res.success) {
//                alert("insert thanh cong");
//                let c = res.data;

//                $("#txtId").val(c.id);
//                var grp = $("#selClass").val();
//                getCourse(grp, 1);
//            } else {
//                alert(res.message);
//            }
//        },
//        failure: function (res) { },
//        error: function (res) { },
//    });
//}

//function deleteCourse(id) {
//    if (confirm("ban co chac xoa course nay?") == false) {
//        return;
//    }
//    if (id != null && id != undefined && id > 0) {
//        $.ajax({
//            type: "POST",
//            url: "/Home/delete_course",
//            data: { 'id': id },
//            async: false,
//            success: function (res) {
//                if (res.success) {
//                    alert("delete thanh cong");
//                    var grp = $("#selClass").val();
//                    var page = parseInt($("#curPage").text());
//                    getCourse(grp, page);
//                } else {
//                    alert(res.message);
//                }
//            },
//            failure: function (res) { },
//            error: function (res) { },
//        });
//    }
//}
// ************************************************
// Shopping Cart API
// ************************************************
var lst = null;
function save() {  //txtId : txtName : txtCity : txtZipCode
    var item = {
        id: $("#txtId").val(),
        fullName: $("#txtName").val(),
        city: $("#txtCity").val(),
        zipCode: $("#txtZipCode").val(),

    };
    $.ajax({
        type: "POST",
        url: "/Home/update_user",
        data: { 'user': item },
        async: false,
        success: function (res) {
            if (res.success) {
                alert("update thanh cong");
                //let c = res.data;
                //var i = 0;
                //for (i = 0; i < lst.length; i++) {
                //    if (lst[i].id == c.id) {
                //        c.STT = lst[i].STT;
                //        break;
                //    }
                //}
                document.location.href = "/home";//return home page after update

                //lst[i] = c;
                //console.log(lst);
                /*$("#tblResult tbody").html("");*/
                /*$("#courseTemplate").tmpl(lst).appendTo("#tblResult tbody");*/
            } else {
                /*alert(res.message);*/
                alert("false");
            }
        },
        failure: function (res) { },
        error: function (res) { },
    });
}


var shoppingCart = (function () {
    // =============================
    // Private methods and propeties
    // =============================
    cart = [];

    // Constructor
    function Item(name, price, count) {
        this.name = name;
        this.price = price;
        this.count = count;
    }

    // Save cart
    function saveCart() {
        sessionStorage.setItem('shoppingCart', JSON.stringify(cart));
    }

    // Load cart
    function loadCart() {
        cart = JSON.parse(sessionStorage.getItem('shoppingCart'));
    }
    if (sessionStorage.getItem("shoppingCart") != null) {
        loadCart();
    }


    // =============================
    // Public methods and propeties
    // =============================
    var obj = {};

    // Add to cart
    obj.addItemToCart = function (name, price, count) {
        for (var item in cart) {
            if (cart[item].name === name) {
                cart[item].count++;
                saveCart();
                return;
            }
        }
        var item = new Item(name, price, count);
        cart.push(item);
        saveCart();
    }
    // Set count from item
    obj.setCountForItem = function (name, count) {
        for (var i in cart) {
            if (cart[i].name === name) {
                cart[i].count = count;
                break;
            }
        }
    };
    // Remove item from cart
    obj.removeItemFromCart = function (name) {
        for (var item in cart) {
            if (cart[item].name === name) {
                cart[item].count--;
                if (cart[item].count === 0) {
                    cart.splice(item, 1);
                }
                break;
            }
        }
        saveCart();
    }

    // Remove all items from cart
    obj.removeItemFromCartAll = function (name) {
        for (var item in cart) {
            if (cart[item].name === name) {
                cart.splice(item, 1);
                break;
            }
        }
        saveCart();
    }

    // Clear cart
    obj.clearCart = function () {
        cart = [];
        saveCart();
    }

    // Count cart 
    obj.totalCount = function () {
        var totalCount = 0;
        for (var item in cart) {
            totalCount += cart[item].count;
        }
        return totalCount;
    }

    // Total cart
    obj.totalCart = function () {
        var totalCart = 0;
        for (var item in cart) {
            totalCart += cart[item].price * cart[item].count;
        }
        return Number(totalCart.toFixed(2));
    }

    // List cart
    obj.listCart = function () {
        var cartCopy = [];
        for (i in cart) {
            item = cart[i];
            itemCopy = {};
            for (p in item) {
                itemCopy[p] = item[p];

            }
            itemCopy.total = Number(item.price * item.count).toFixed(2);
            cartCopy.push(itemCopy)
        }
        return cartCopy;
    }

    // cart : Array
    // Item : Object/Class
    // addItemToCart : Function
    // removeItemFromCart : Function
    // removeItemFromCartAll : Function
    // clearCart : Function
    // countCart : Function
    // totalCart : Function
    // listCart : Function
    // saveCart : Function
    // loadCart : Function
    return obj;
})();


// *****************************************
// Triggers / Events
// ***************************************** 
// Add item
$('.add-to-cart').click(function (event) {
    event.preventDefault();
    var name = $(this).data('name');
    var price = Number($(this).data('price'));
    shoppingCart.addItemToCart(name, price, 1);
    displayCart();
});

// Clear items
$('.clear-cart').click(function () {
    shoppingCart.clearCart();
    displayCart();
});


function displayCart() {
    var cartArray = shoppingCart.listCart();
    var output = "";
    for (var i in cartArray) {
        output += "<tr>"
            + "<td>" + cartArray[i].name + "</td>"
            + "<td>(" + cartArray[i].price + ")</td>"
            + "<td><div class='input-group'><button class='minus-item input-group-addon btn btn-primary' data-name=" + cartArray[i].name + ">-</button>"
            + "<input type='number' class='item-count form-control' data-name='" + cartArray[i].name + "' value='" + cartArray[i].count + "'>"
            + "<button class='plus-item btn btn-primary input-group-addon' data-name=" + cartArray[i].name + ">+</button></div></td>"
            + "<td><button class='delete-item btn btn-danger' data-name=" + cartArray[i].name + ">X</button></td>"
            + " = "
            + "<td>" + cartArray[i].total + "</td>"
            + "</tr>";
    }
    $('.show-cart').html(output);
    $('.total-cart').html(shoppingCart.totalCart());
    $('.total-count').html(shoppingCart.totalCount());
}

// Delete item button

$('.show-cart').on("click", ".delete-item", function (event) {
    var name = $(this).data('name')
    shoppingCart.removeItemFromCartAll(name);
    displayCart();
})


// -1
$('.show-cart').on("click", ".minus-item", function (event) {
    var name = $(this).data('name')
    shoppingCart.removeItemFromCart(name);
    displayCart();
})
// +1
$('.show-cart').on("click", ".plus-item", function (event) {
    var name = $(this).data('name')
    shoppingCart.addItemToCart(name);
    displayCart();
})

// Item count input
$('.show-cart').on("change", ".item-count", function (event) {
    var name = $(this).data('name');
    var count = Number($(this).val());
    shoppingCart.setCountForItem(name, count);
    displayCart();
});

displayCart();
