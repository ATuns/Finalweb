﻿using Microsoft.AspNetCore.Mvc;

namespace FinalWeb.Controllers
{
    public class testController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
